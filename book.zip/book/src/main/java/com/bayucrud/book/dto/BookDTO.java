package com.bayucrud.book.dto;

import lombok.Data;

@Data
public class BookDTO {
    private String title;
}
