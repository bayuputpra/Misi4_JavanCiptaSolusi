package com.bayucrud.book.controller;

import com.bayucrud.book.dto.BookDTO;
import com.bayucrud.book.entity.Book;
import com.bayucrud.book.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/book")
public class BookController {

    @Autowired
    private BookService bookService;

    /**
     * add book
     */

    @PostMapping("/add")
    public String addBook(@RequestBody Book book) {
        bookService.addBook(book);

        return "success add book";
    }

    /**
     * get books as list
     */

    @GetMapping
    public List<Book> getBooks() {
        return bookService.getBooks();
    }

    /**
     * get book by id
     */

    @GetMapping("/get")
    public Book getBook(@RequestParam Integer id) {
        return bookService.getBook(id);
    }

    /**
     * update book
     */

    @PutMapping("/update/{id}")
    public ResponseEntity<Void> updateBook(@PathVariable Integer id, @RequestBody Book book) {
        bookService.updateBook(id, book);

        return ResponseEntity.noContent().build();
    }

    /**
     * delete book
     */

    @DeleteMapping("delete/{id}")
    public ResponseEntity<Void> deleteBook(@PathVariable Integer id){
        bookService.deleteBook(id);

        return ResponseEntity.noContent().build();
    }

    /**
     * update title
     */

    @PatchMapping("/update-title/{id}")
    public ResponseEntity<Void> updateTitle(@PathVariable Integer id, @RequestBody BookDTO bookDTO){
        bookService.updateTitle(id, bookDTO);

        return ResponseEntity.noContent().build();
    }

}
