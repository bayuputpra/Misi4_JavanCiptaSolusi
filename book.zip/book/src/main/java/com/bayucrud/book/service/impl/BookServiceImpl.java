package com.bayucrud.book.service.impl;

import com.bayucrud.book.dto.BookDTO;
import com.bayucrud.book.entity.Book;
import com.bayucrud.book.repository.BookRepository;
import com.bayucrud.book.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
public class BookServiceImpl implements BookService {
    @Autowired
    private BookRepository bookRepository;

    /**
     * add book
     */
    @Override
    public void addBook(Book book) {
        bookRepository.save(book);
    }

    /**
     * get book as list
     */
    @Override
    public List<Book> getBooks() {
        return bookRepository.findAll();
    }

    /**
     * get book by id
     */

    @Override
    public Book getBook(Integer id) {
//        check weather the book is in database or not
        Book book = bookRepository
                .findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Invalid book Id:" + id));

        return book;
    }

    /**
     * update book
     */

    @Override
    public void updateBook(Integer id, Book book) {
//        check weather the book is in database or not
        bookRepository
                .findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Invalid book Id:" + id));

        book.setId(id);

        bookRepository.save(book);

    }

    @Override
    public void deleteBook(Integer id) {
//        check weather the book is in database or not
        Book book = bookRepository
                .findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Invalid book Id:" + id));

        bookRepository.delete(book);
    }

    @Override
    public void updateTitle(Integer id, BookDTO bookDTO) {
//        check weather the book is in database or not
        Book book = bookRepository
                .findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Invalid book Id:" + id));

        book.setTitle(bookDTO.getTitle());

        bookRepository.save(book);

    }
}
