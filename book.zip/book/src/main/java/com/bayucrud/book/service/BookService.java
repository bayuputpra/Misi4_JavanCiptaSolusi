package com.bayucrud.book.service;

import com.bayucrud.book.dto.BookDTO;
import com.bayucrud.book.entity.Book;

import java.util.List;

public interface BookService {
    void addBook(Book book);

    List<Book> getBooks();

    Book getBook(Integer id);

    void updateBook(Integer id, Book book);

    void deleteBook(Integer id);

    void updateTitle(Integer id, BookDTO bookDTO);
}
